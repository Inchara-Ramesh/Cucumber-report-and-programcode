$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity4.feature");
formatter.feature({
  "line": 2,
  "name": "Data driven test with Example",
  "description": "",
  "id": "data-driven-test-with-example",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_4"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": ": Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;:-testing-with-data-from-scenario",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "User4 is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User4 enters \"orange \" and \"orangepassword123\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "click4 on the vacany and add new vacancy and \"\u003cvacancyname\u003e\" and \"\u003chiringmanager\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close4 the Browser",
  "keyword": "And "
});
formatter.examples({
  "line": 9,
  "name": "",
  "description": "",
  "id": "data-driven-test-with-example;:-testing-with-data-from-scenario;",
  "rows": [
    {
      "cells": [
        "vacancyname",
        "hiringmanager"
      ],
      "line": 10,
      "id": "data-driven-test-with-example;:-testing-with-data-from-scenario;;1"
    },
    {
      "cells": [
        "aaaaaaaaaaaaaaaaaauyuyuypp",
        "John Doe"
      ],
      "line": 11,
      "id": "data-driven-test-with-example;:-testing-with-data-from-scenario;;2"
    },
    {
      "cells": [
        "aaaaaaaaaaaaaaaaaahjhjhjpp",
        "John Doe"
      ],
      "line": 12,
      "id": "data-driven-test-with-example;:-testing-with-data-from-scenario;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 11,
  "name": ": Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;:-testing-with-data-from-scenario;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_4"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User4 is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User4 enters \"orange \" and \"orangepassword123\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "click4 on the vacany and add new vacancy and \"aaaaaaaaaaaaaaaaaauyuyuypp\" and \"John Doe\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close4 the Browser",
  "keyword": "And "
});
formatter.match({
  "location": "Activity4.loginPage()"
});
formatter.result({
  "duration": 8786888900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "orange ",
      "offset": 14
    },
    {
      "val": "orangepassword123",
      "offset": 28
    }
  ],
  "location": "Activity4.user_enters_and(String,String)"
});
formatter.result({
  "duration": 6060272200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "aaaaaaaaaaaaaaaaaauyuyuypp",
      "offset": 46
    },
    {
      "val": "John Doe",
      "offset": 79
    }
  ],
  "location": "Activity4.adduser(String,String)"
});
formatter.result({
  "duration": 6163542500,
  "status": "passed"
});
formatter.match({
  "location": "Activity4.closeBrowser()"
});
formatter.result({
  "duration": 1186723600,
  "status": "passed"
});
formatter.scenario({
  "line": 12,
  "name": ": Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;:-testing-with-data-from-scenario;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_4"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User4 is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User4 enters \"orange \" and \"orangepassword123\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "click4 on the vacany and add new vacancy and \"aaaaaaaaaaaaaaaaaahjhjhjpp\" and \"John Doe\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close4 the Browser",
  "keyword": "And "
});
formatter.match({
  "location": "Activity4.loginPage()"
});
formatter.result({
  "duration": 9695741900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "orange ",
      "offset": 14
    },
    {
      "val": "orangepassword123",
      "offset": 28
    }
  ],
  "location": "Activity4.user_enters_and(String,String)"
});
formatter.result({
  "duration": 3411167200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "aaaaaaaaaaaaaaaaaahjhjhjpp",
      "offset": 46
    },
    {
      "val": "John Doe",
      "offset": 79
    }
  ],
  "location": "Activity4.adduser(String,String)"
});
formatter.result({
  "duration": 10057422600,
  "status": "passed"
});
formatter.match({
  "location": "Activity4.closeBrowser()"
});
formatter.result({
  "duration": 1147473200,
  "status": "passed"
});
});