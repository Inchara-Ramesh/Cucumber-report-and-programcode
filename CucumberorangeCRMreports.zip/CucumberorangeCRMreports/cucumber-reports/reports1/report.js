$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity1.feature");
formatter.feature({
  "line": 2,
  "name": "Data driven test with Example",
  "description": "",
  "id": "data-driven-test-with-example",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_1"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "User5 is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User5 enters \"orange\" and \"orangepassword123\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "click on the vacany and add new vacancy",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close7 the Browser",
  "keyword": "And "
});
formatter.match({
  "location": "Activity1.loginPage()"
});
formatter.result({
  "duration": 8962289500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "orange",
      "offset": 14
    },
    {
      "val": "orangepassword123",
      "offset": 27
    }
  ],
  "location": "Activity1.user_enters_and(String,String)"
});
formatter.result({
  "duration": 4522939600,
  "status": "passed"
});
formatter.match({
  "location": "Activity1.adduser()"
});
formatter.result({
  "duration": 5988532900,
  "status": "passed"
});
formatter.match({
  "location": "Activity1.closeBrowser()"
});
formatter.result({
  "duration": 1184899100,
  "status": "passed"
});
});