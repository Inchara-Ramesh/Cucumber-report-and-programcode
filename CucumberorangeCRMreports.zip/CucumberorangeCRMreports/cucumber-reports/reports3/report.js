$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity3.feature");
formatter.feature({
  "line": 2,
  "name": "Data driven test with Example",
  "description": "",
  "id": "data-driven-test-with-example",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_3"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": ": Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;:-testing-with-data-from-scenario",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "User3 is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User3 enters \"orange\" and \"orangepassword123\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "click3 on the PIM and add new candidate",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "User8 enters \"\u003cFullname\u003e\" and \"\u003cLastname\u003e\" and \"\u003cusername\u003e\" and \"\u003cpassword\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "Close3 the Browser",
  "keyword": "And "
});
formatter.examples({
  "line": 10,
  "name": "",
  "description": "",
  "id": "data-driven-test-with-example;:-testing-with-data-from-scenario;",
  "rows": [
    {
      "cells": [
        "Fullname",
        "Lastname",
        "username",
        "password"
      ],
      "line": 11,
      "id": "data-driven-test-with-example;:-testing-with-data-from-scenario;;1"
    },
    {
      "cells": [
        "orajkusuti",
        "orankkgepaouuti",
        "khkkkklkkluuti",
        "124567786"
      ],
      "line": 12,
      "id": "data-driven-test-with-example;:-testing-with-data-from-scenario;;2"
    },
    {
      "cells": [
        "incharaatu",
        "Rameshhsjjtu",
        "jhiiiiuiujjjtu",
        "127897786"
      ],
      "line": 13,
      "id": "data-driven-test-with-example;:-testing-with-data-from-scenario;;3"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 12,
  "name": ": Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;:-testing-with-data-from-scenario;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_3"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User3 is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User3 enters \"orange\" and \"orangepassword123\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "click3 on the PIM and add new candidate",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "User8 enters \"orajkusuti\" and \"orankkgepaouuti\" and \"khkkkklkkluuti\" and \"124567786\"",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "Close3 the Browser",
  "keyword": "And "
});
formatter.match({
  "location": "Activity3.loginPage()"
});
formatter.result({
  "duration": 10608130300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "orange",
      "offset": 14
    },
    {
      "val": "orangepassword123",
      "offset": 27
    }
  ],
  "location": "Activity3.user_enters_and(String,String)"
});
formatter.result({
  "duration": 3524147400,
  "status": "passed"
});
formatter.match({
  "location": "Activity3.adduser()"
});
formatter.result({
  "duration": 4664910100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "orajkusuti",
      "offset": 14
    },
    {
      "val": "orankkgepaouuti",
      "offset": 31
    },
    {
      "val": "khkkkklkkluuti",
      "offset": 53
    },
    {
      "val": "124567786",
      "offset": 74
    }
  ],
  "location": "Activity3.createemployee(String,String,String,String)"
});
formatter.result({
  "duration": 4371959500,
  "status": "passed"
});
formatter.match({
  "location": "Activity3.closeBrowser()"
});
formatter.result({
  "duration": 1256750900,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": ": Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;:-testing-with-data-from-scenario;;3",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_3"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User3 is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User3 enters \"orange\" and \"orangepassword123\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "click3 on the PIM and add new candidate",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "User8 enters \"incharaatu\" and \"Rameshhsjjtu\" and \"jhiiiiuiujjjtu\" and \"127897786\"",
  "matchedColumns": [
    0,
    1,
    2,
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "Close3 the Browser",
  "keyword": "And "
});
formatter.match({
  "location": "Activity3.loginPage()"
});
formatter.result({
  "duration": 8175558800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "orange",
      "offset": 14
    },
    {
      "val": "orangepassword123",
      "offset": 27
    }
  ],
  "location": "Activity3.user_enters_and(String,String)"
});
formatter.result({
  "duration": 3739598300,
  "status": "passed"
});
formatter.match({
  "location": "Activity3.adduser()"
});
formatter.result({
  "duration": 3628901700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "incharaatu",
      "offset": 14
    },
    {
      "val": "Rameshhsjjtu",
      "offset": 31
    },
    {
      "val": "jhiiiiuiujjjtu",
      "offset": 50
    },
    {
      "val": "127897786",
      "offset": 71
    }
  ],
  "location": "Activity3.createemployee(String,String,String,String)"
});
formatter.result({
  "duration": 4738789700,
  "status": "passed"
});
formatter.match({
  "location": "Activity3.closeBrowser()"
});
formatter.result({
  "duration": 1133288000,
  "status": "passed"
});
});