$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity2.feature");
formatter.feature({
  "line": 2,
  "name": "Data driven test with Example",
  "description": "",
  "id": "data-driven-test-with-example",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_2"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": ": Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;:-testing-with-data-from-scenario",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "User2 is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User2 enters \"\u003cUsernames\u003e\" and \"\u003cPasswords\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "click on the candidates and add new candidate",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close2 the Browser",
  "keyword": "And "
});
formatter.examples({
  "line": 9,
  "name": "",
  "description": "",
  "id": "data-driven-test-with-example;:-testing-with-data-from-scenario;",
  "rows": [
    {
      "cells": [
        "Usernames",
        "Passwords"
      ],
      "line": 10,
      "id": "data-driven-test-with-example;:-testing-with-data-from-scenario;;1"
    },
    {
      "cells": [
        "orange",
        "orangepassword123"
      ],
      "line": 11,
      "id": "data-driven-test-with-example;:-testing-with-data-from-scenario;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 11,
  "name": ": Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;:-testing-with-data-from-scenario;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_2"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User2 is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User2 enters \"orange\" and \"orangepassword123\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "click on the candidates and add new candidate",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close2 the Browser",
  "keyword": "And "
});
formatter.match({
  "location": "Activity2.loginPage()"
});
formatter.result({
  "duration": 14532486000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "orange",
      "offset": 14
    },
    {
      "val": "orangepassword123",
      "offset": 27
    }
  ],
  "location": "Activity2.user_enters_and(String,String)"
});
formatter.result({
  "duration": 5131172300,
  "status": "passed"
});
formatter.match({
  "location": "Activity2.adduser()"
});
formatter.result({
  "duration": 8467277400,
  "status": "passed"
});
formatter.match({
  "location": "Activity2.closeBrowser()"
});
formatter.result({
  "duration": 1233663300,
  "status": "passed"
});
});