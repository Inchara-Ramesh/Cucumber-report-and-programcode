package StepDefinitions;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class Activity3 {
    WebDriver driver;
    WebDriverWait wait;
    
    @Given("^User7 is on Login page and navigate to post jobs page$")
    public void loginPage() {
        //Setup instances
        driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
        
        //Open browser
        driver.get("https://alchemy.hguy.co/jobs/");
        driver.findElement(By.linkText("Post a Job")).click();
    }
    @Then("^user logs in with email \"(.*)\"$")
    public void email(String email) {
    	//add
    	driver.findElement(By.id("create_account_email")).sendKeys(email);
    	
    	  }
    @Then("^user logs in with location \"(.*)\"$")
    public void location(String location) {
    	//add
    	driver.findElement(By.id("job_location")).sendKeys(location);
    	
    	  }
    
     @Then("^user logs in with jobtitle \"(.*)\"$")
    public void title(String jobtitle) {
    	//add
    	driver.findElement(By.id("job_title")).sendKeys(jobtitle);
    	
    	  }
     @Then("^user logs in with appliacation url \"(.*)\"$")
     public void URL(String URL) {
     	//add
     	driver.findElement(By.id("application")).sendKeys(URL);
     	
     	  }
     @Then("^user logs in with description$")
     public void description() {
     	//add
    driver.findElement(By.xpath("//*[@id=\"mceu_2-button\"]")).click();
     	  }
     
     @Then("^user logs in with companyname \"(.*)\"$")
     public void companyname(String companyname) {
     	//add
     	driver.findElement(By.id("company_name")).sendKeys(companyname);
     	
     	  }
     
     @Then("^User7 is on Login page and navigate to post jobs page and verify jobs are created$")
     public void previewbutton() {
         //Setup instances
        driver.findElement(By.xpath("/html/body/div[1]/div/div/div/main/article/div/form/p/input[4]")).click();
        driver.findElement(By.xpath("//*[@id=\"job_preview_submit_button\"]")).click();
        driver.findElement(By.linkText("Jobs")).click();
        driver.findElement(By.xpath("//*[@id=\"job_type_freelance\"]")).click();
    	driver.findElement(By.xpath("//*[@id=\"job_type_internship\"]")).click();
    	driver.findElement(By.xpath("//*[@id=\"job_type_part-time\"]")).click();
    	driver.findElement(By.xpath("//*[@id=\"job_type_temporary\"]")).click();
    	driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
    	driver.findElement(By.xpath("//*[@id=\"search_keywords\"]")).sendKeys("Automation Tester", Keys.RETURN);
    String gettingtext	=driver.findElement(By.xpath("/html/body/div[2]/div/div/div/main/article/div/div/ul/li/a/div[1]/h3")).getText();
    Assert.assertEquals("Automation Tester", gettingtext);
        }
     
    
    
    
    
        
      
       
    
    @And("^Close7 the Browser$")
    public void closeBrowser() {
        //Close browser
     driver.close();
    }

}