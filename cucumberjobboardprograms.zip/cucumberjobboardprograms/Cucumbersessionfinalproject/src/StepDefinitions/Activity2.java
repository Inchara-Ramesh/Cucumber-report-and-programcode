package StepDefinitions;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class Activity2 {
    WebDriver driver;
    WebDriverWait wait;
    
    @Given("^User6 is on Login page and navigate to jobs page$")
    public void loginPage() {
        //Setup instances
        driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
        
        //Open browser
        driver.get("https://alchemy.hguy.co/jobs/");
        driver.findElement(By.linkText("Jobs")).click();
    }
    
   
    @Then("^uncheck checkbox and search for keyword$")
    public void uncheckcheckbox() {
    	//add
    	driver.findElement(By.xpath("//*[@id=\"job_type_freelance\"]")).click();
    	driver.findElement(By.xpath("//*[@id=\"job_type_internship\"]")).click();
    	driver.findElement(By.xpath("//*[@id=\"job_type_part-time\"]")).click();
    	driver.findElement(By.xpath("//*[@id=\"job_type_temporary\"]")).click();
    	driver.findElement(By.xpath("//*[@id=\"search_keywords\"]")).sendKeys("testing", Keys.RETURN);
    	//*[@id="search_keywords"]
    	
    }
    @Then("^clicking on particular job and apply for job$")
    public void adduserdetails() {
    	//add 
    	driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
    	driver.findElement(By.xpath("/html/body/div/div/div/div/main/article/div/div/ul/li[1]/a/div[1]/h3")).click();
    	driver.findElement(By.xpath("/html/body/div/div/div/div/main/nav/div/div/a")).click();
    	
    String	gettitle =driver.findElement(By.className("entry-title")).getText();
    System.out.println(gettitle);
    driver.findElement(By.xpath("//input[@value=\"Apply for job\"]")).click();
    	 }
    
    
        
      
       
    
    @And("^Close6 the Browser$")
    public void closeBrowser() {
        //Close browser
       driver.close();
    }

}