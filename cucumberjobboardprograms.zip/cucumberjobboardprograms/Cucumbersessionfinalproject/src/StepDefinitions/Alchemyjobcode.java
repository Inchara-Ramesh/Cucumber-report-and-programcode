package StepDefinitions;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class Alchemyjobcode {
    WebDriver driver;
    WebDriverWait wait;
    
    @Given("^User5 is on Login page$")
    public void loginPage() {
        //Setup instances
        driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
        
        //Open browser
        driver.get("https://alchemy.hguy.co/jobs/wp-login.php");
    }
    
   

    @When("^User5 enters \"(.*)\" and \"(.*)\"$")
    public void user_enters_and(String username, String password) throws Throwable {
        //Enter username from Feature file
        driver.findElement(By.id("user_login")).sendKeys(username);
        //Enter password from Feature file
        driver.findElement(By.id("user_pass")).sendKeys(password);
        //Click Login
        driver.findElement(By.xpath("//*[@id=\"wp-submit\"]")).click();
    }
    
    @Then("^click on the user and add new user$")
    public void adduser() {
    	wait = new WebDriverWait(driver, 5);
    	driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
    	driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/ul/li[11]/a/div[2]")).click();
    	driver.findElement(By.linkText("Add New")).click();
    }
    @Then("^adding user details and search the user$")
    public void adduserdetails() {
    	wait = new WebDriverWait(driver, 5);
    	driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
    	driver.findElement(By.id("user_login")).sendKeys("Inchararamesha");
    	driver.findElement(By.id("email")).sendKeys("kkkkkkdcc@gmail.com");
    	driver.findElement(By.id("first_name")).sendKeys("Aincharaa");
    	driver.findElement(By.id("last_name")).sendKeys("Aramesha");
    	driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    	
    	driver.findElement(By.xpath("//button[@class=\"button wp-generate-pw hide-if-no-js\"]")).click();
    	driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    	driver.findElement(By.xpath("//*[@id=\"pass1\"]")).sendKeys("inchara@123456");
    	
    	
    	driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/div[4]/form/table/tbody/tr[8]/td/label/input")).click();
    	//driver.findElement(By.xpath("//input[@id=\"createusersub\"]")).click();
    	wait = new WebDriverWait(driver, 5);
    	wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@type=\"submit\"]")));
    	driver.findElement(By.xpath("//*[@type=\"submit\"]")).click();
    	driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    	driver.findElement(By.id("user-search-input")).sendKeys("Aincharaa");
    	driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    	driver.findElement(By.id("search-submit")).click();
    String gettingtesxt =	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/div[4]/form/table/tbody/tr/td[2]")).getText();
    	Assert.assertEquals("Aincharaa Aramesha", gettingtesxt);
    	 }
    
    
        
      
       
    
    @And("^Close5 the Browser$")
    public void closeBrowser() {
        //Close browser
       driver.close();
    }

}