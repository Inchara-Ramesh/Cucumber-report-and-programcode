package StepDefinitions;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class Activity1 {
    WebDriver driver;
    WebDriverWait wait;
    
    @Given("^User5 is on Login page$")
    public void loginPage() {
        //Setup instances
        driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
        
        //Open browser
        driver.get("http://alchemy.hguy.co:8080/orangehrm/symfony/web/index.php/auth/login");
    }
    
   

    @When("^User5 enters \"(.*)\" and \"(.*)\"$")
    public void user_enters_and(String username, String password) throws Throwable {
        //Enter username from Feature file
        driver.findElement(By.id("txtUsername")).sendKeys(username);
        //Enter password from Feature file
        driver.findElement(By.id("txtPassword")).sendKeys(password);
        //Click Login
        driver.findElement(By.xpath("//*[@id=\"btnLogin\"]")).click();
    }
    
    @Then("^click on the vacany and add new vacancy$")
    public void adduser() {
    	wait = new WebDriverWait(driver, 5);
    	driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
    	
    	driver.findElement(By.linkText("Recruitment")).click();
    	driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
    	driver.findElement(By.linkText("Vacancies")).click();
    	driver.findElement(By.id("btnAdd")).click();
    	driver.findElement(By.id("addJobVacancy_jobTitle")).click();
    	driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/div[2]/form/fieldset/ol/li[1]/select/option[3]")).click();
    	driver.findElement(By.id("addJobVacancy_name")).sendKeys("aaaaaaaaaaaaaaaaaaaabbbbi");
    	driver.findElement(By.id("addJobVacancy_hiringManager")).sendKeys("John Doe");
    	driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
    	driver.findElement(By.id("btnSave")).click();
    	driver.findElement(By.id("btnBack")).click();
    String gettingtext =	driver.findElement(By.linkText("aaaaaaaaaaaaaaaaaaaabbbbi")).getText();
   Assert.assertEquals("aaaaaaaaaaaaaaaaaaaabbbbi", gettingtext);
    
    	
    }
  
    
        
      
       
    
    @And("^Close7 the Browser$")
    public void closeBrowser() {
        //Close browser
       driver.close();
    }

}