$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity1.feature");
formatter.feature({
  "line": 2,
  "name": "suite crm project activities",
  "description": "",
  "id": "suite-crm-project-activities",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity3_1"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Testing with Data from Scenario",
  "description": "",
  "id": "suite-crm-project-activities;testing-with-data-from-scenario",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "User1 is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Usersuitecrm enters \"admin\" and \"pa$$w0rd\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "Count the number of Dashlets on the homepage",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close1 the Browser",
  "keyword": "And "
});
formatter.match({
  "location": "Activity1.loginPage()"
});
formatter.result({
  "duration": 23309149900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "admin",
      "offset": 21
    },
    {
      "val": "pa$$w0rd",
      "offset": 33
    }
  ],
  "location": "Activity1.user_enters_and(String,String)"
});
formatter.result({
  "duration": 6076442100,
  "status": "passed"
});
formatter.match({
  "location": "Activity1.adduser()"
});
formatter.result({
  "duration": 1411051200,
  "status": "passed"
});
formatter.match({
  "location": "Activity1.closeBrowser()"
});
formatter.result({
  "duration": 3490709900,
  "status": "passed"
});
});