$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity3.feature");
formatter.feature({
  "line": 2,
  "name": "Data driven test with Example",
  "description": "",
  "id": "data-driven-test-with-example",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity3_3"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": "Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "User3 is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Usersuitecrm3 enters \"admin\" and \"pa$$w0rd\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "create3 Meetings using details \"\u003cfirstname\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close4 the Browser",
  "keyword": "And "
});
formatter.examples({
  "line": 9,
  "name": "",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario;",
  "rows": [
    {
      "cells": [
        "firstname"
      ],
      "line": 10,
      "id": "data-driven-test-with-example;testing-with-data-from-scenario;;1"
    },
    {
      "cells": [
        "Inchara"
      ],
      "line": 11,
      "id": "data-driven-test-with-example;testing-with-data-from-scenario;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 11,
  "name": "Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@activity3_3"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User3 is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Usersuitecrm3 enters \"admin\" and \"pa$$w0rd\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "create3 Meetings using details \"Inchara\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close4 the Browser",
  "keyword": "And "
});
formatter.match({
  "location": "Activity3.loginPage()"
});
formatter.result({
  "duration": 21374687100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "admin",
      "offset": 22
    },
    {
      "val": "pa$$w0rd",
      "offset": 34
    }
  ],
  "location": "Activity3.user_enters_and(String,String)"
});
formatter.result({
  "duration": 6520102000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Inchara",
      "offset": 32
    }
  ],
  "location": "Activity3.adduser(String)"
});
formatter.result({
  "duration": 52227042400,
  "status": "passed"
});
formatter.match({
  "location": "Activity3.closeBrowser()"
});
formatter.result({
  "duration": 38100,
  "status": "passed"
});
});