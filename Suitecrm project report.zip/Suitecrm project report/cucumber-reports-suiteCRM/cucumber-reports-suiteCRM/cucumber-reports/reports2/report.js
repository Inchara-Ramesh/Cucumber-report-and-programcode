$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity2.feature");
formatter.feature({
  "line": 2,
  "name": "Data driven test with Example",
  "description": "",
  "id": "data-driven-test-with-example",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity3_2"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "User2 is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Usersuitecrm2 enters \"admin\" and \"pa$$w0rd\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "create leads using details \"Inchara\" and \"ramesh\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close3 the Browser",
  "keyword": "And "
});
formatter.match({
  "location": "Activity2.loginPage()"
});
formatter.result({
  "duration": 23976533400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "admin",
      "offset": 22
    },
    {
      "val": "pa$$w0rd",
      "offset": 34
    }
  ],
  "location": "Activity2.user_enters_and(String,String)"
});
formatter.result({
  "duration": 4762220800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Inchara",
      "offset": 28
    },
    {
      "val": "ramesh",
      "offset": 42
    }
  ],
  "location": "Activity2.adduser(String,String)"
});
formatter.result({
  "duration": 32191344300,
  "status": "passed"
});
formatter.match({
  "location": "Activity2.closeBrowser()"
});
formatter.result({
  "duration": 2358917500,
  "status": "passed"
});
});