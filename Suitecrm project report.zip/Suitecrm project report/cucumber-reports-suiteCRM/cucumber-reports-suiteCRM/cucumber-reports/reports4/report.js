$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity4.feature");
formatter.feature({
  "line": 2,
  "name": "Data driven test with Example",
  "description": "",
  "id": "data-driven-test-with-example",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity3_4"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": "Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "User4 is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Usersuitecrm4 enters \"admin\" and \"pa$$w0rd\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "create4 products using details \"\u003cproductname\u003e\" and \"\u003cprice\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close5 the Browser",
  "keyword": "And "
});
formatter.examples({
  "line": 9,
  "name": "",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario;",
  "rows": [
    {
      "cells": [
        "productname",
        "price"
      ],
      "line": 10,
      "id": "data-driven-test-with-example;testing-with-data-from-scenario;;1"
    },
    {
      "cells": [
        "Inchara",
        "63"
      ],
      "line": 11,
      "id": "data-driven-test-with-example;testing-with-data-from-scenario;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 11,
  "name": "Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@activity3_4"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User4 is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "Usersuitecrm4 enters \"admin\" and \"pa$$w0rd\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "create4 products using details \"Inchara\" and \"63\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close5 the Browser",
  "keyword": "And "
});
formatter.match({
  "location": "Activity4.loginPage()"
});
formatter.result({
  "duration": 24771522200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "admin",
      "offset": 22
    },
    {
      "val": "pa$$w0rd",
      "offset": 34
    }
  ],
  "location": "Activity4.user_enters_and(String,String)"
});
formatter.result({
  "duration": 8221503800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Inchara",
      "offset": 32
    },
    {
      "val": "63",
      "offset": 46
    }
  ],
  "location": "Activity4.adduser(String,String)"
});
formatter.result({
  "duration": 31837462200,
  "status": "passed"
});
formatter.match({
  "location": "Activity4.closeBrowser()"
});
formatter.result({
  "duration": 44400,
  "status": "passed"
});
});