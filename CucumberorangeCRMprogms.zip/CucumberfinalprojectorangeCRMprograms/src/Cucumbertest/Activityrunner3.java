package Cucumbertest;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
    features = "Features",
    glue = {"StepDefinitions"},
    tags = {"@activity2_3"},
    strict = true,
    plugin = { "pretty","html:target/cucumber-reports/reports3"},
    monochrome = true
)

public class Activityrunner3 {}