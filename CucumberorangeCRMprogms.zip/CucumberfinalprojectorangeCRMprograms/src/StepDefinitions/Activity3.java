package StepDefinitions;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class Activity3 {
    WebDriver driver;
    WebDriverWait wait;
    
    @Given("^User3 is on Login page$")
    public void loginPage() {
        //Setup instances
        driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
        
        //Open browser
        driver.get("http://alchemy.hguy.co:8080/orangehrm/symfony/web/index.php/auth/login");
    }
    
   

    @When("^User3 enters \"(.*)\" and \"(.*)\"$")
    public void user_enters_and(String username, String password) throws Throwable {
        //Enter username from Feature file
        driver.findElement(By.id("txtUsername")).sendKeys(username);
        //Enter password from Feature file
        driver.findElement(By.id("txtPassword")).sendKeys(password);
        //Click Login
        driver.findElement(By.xpath("//*[@id=\"btnLogin\"]")).click();
    }
    
    @Then("^click3 on the PIM and add new candidate$")
    public void adduser() {
    	wait = new WebDriverWait(driver, 5);
    	driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
    	
    	driver.findElement(By.linkText("PIM")).click();
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	
    	driver.findElement(By.linkText("Employee List")).click();
    	driver.findElement(By.id("btnAdd")).click();
    	driver.findElement(By.id("chkLogin")).click();
    	}
  @Then("^User8 enters \"(.*)\" and \"(.*)\" and \"(.*)\" and \"(.*)\"$")
   public void createemployee(String Fullname,String Lastname, String username ,String password) throws Throwable {
	  driver.findElement(By.id("firstName")).sendKeys(Fullname);
	  driver.findElement(By.id("lastName")).sendKeys(Lastname);
	  driver.findElement(By.id("employeeId")).clear();
	  driver.findElement(By.id("employeeId")).sendKeys(password);
	String firstname =  driver.findElement(By.id("firstName")).getText();
	
	 
	 System.out.println(firstname);
	  driver.findElement(By.id("user_name")).sendKeys(username);
	  driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
      driver.findElement(By.id("btnSave")).click();
      driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
      driver.findElement(By.linkText("Employee List")).click();
      driver.findElement(By.id("empsearch_id")).sendKeys(password);
      driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
      driver.findElement(By.id("searchBtn")).click();
      String gettingtext =	driver.findElement(By.linkText(firstname)).getText();
      Assert.assertEquals(firstname, gettingtext);
      
      
  }
	  
  
  
    
        
      
       
    
    @And("^Close3 the Browser$")
    public void closeBrowser() {
        //Close browser
      driver.close();
    }

}