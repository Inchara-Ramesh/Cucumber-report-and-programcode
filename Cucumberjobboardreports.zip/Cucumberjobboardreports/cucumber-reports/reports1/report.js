$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Alchemyjobs.feature");
formatter.feature({
  "line": 2,
  "name": "Data driven test with Example",
  "description": "",
  "id": "data-driven-test-with-example",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_5"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": "Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "User5 is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User5 enters \"\u003cUsernames\u003e\" and \"\u003cPasswords\u003e\"",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "click on the user and add new user",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "adding user details and search the user",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "Close5 the Browser",
  "keyword": "And "
});
formatter.examples({
  "line": 11,
  "name": "",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario;",
  "rows": [
    {
      "cells": [
        "Usernames",
        "Passwords"
      ],
      "line": 12,
      "id": "data-driven-test-with-example;testing-with-data-from-scenario;;1"
    },
    {
      "cells": [
        "root",
        "pa$$w0rd"
      ],
      "line": 13,
      "id": "data-driven-test-with-example;testing-with-data-from-scenario;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 13,
  "name": "Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_5"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User5 is on Login page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "User5 enters \"root\" and \"pa$$w0rd\"",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "click on the user and add new user",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "adding user details and search the user",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "Close5 the Browser",
  "keyword": "And "
});
formatter.match({
  "location": "Alchemyjobcode.loginPage()"
});
formatter.result({
  "duration": 8506102600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "root",
      "offset": 14
    },
    {
      "val": "pa$$w0rd",
      "offset": 25
    }
  ],
  "location": "Alchemyjobcode.user_enters_and(String,String)"
});
formatter.result({
  "duration": 7040764900,
  "status": "passed"
});
formatter.match({
  "location": "Alchemyjobcode.adduser()"
});
formatter.result({
  "duration": 3555871200,
  "status": "passed"
});
formatter.match({
  "location": "Alchemyjobcode.adduserdetails()"
});
formatter.result({
  "duration": 32059637400,
  "status": "passed"
});
formatter.match({
  "location": "Alchemyjobcode.closeBrowser()"
});
formatter.result({
  "duration": 1217593800,
  "status": "passed"
});
});