$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity2.feature");
formatter.feature({
  "line": 2,
  "name": "Data driven test with Example",
  "description": "",
  "id": "data-driven-test-with-example",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_6"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": "Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "User6 is on Login page and navigate to jobs page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "uncheck checkbox and search for keyword",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "clicking on particular job and apply for job",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close6 the Browser",
  "keyword": "And "
});
formatter.examples({
  "line": 10,
  "name": "",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario;",
  "rows": [
    {
      "cells": [
        "Usernames",
        "Passwords"
      ],
      "line": 11,
      "id": "data-driven-test-with-example;testing-with-data-from-scenario;;1"
    },
    {
      "cells": [
        "root",
        "pa$$w0rd"
      ],
      "line": 12,
      "id": "data-driven-test-with-example;testing-with-data-from-scenario;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 12,
  "name": "Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_6"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User6 is on Login page and navigate to jobs page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "uncheck checkbox and search for keyword",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "clicking on particular job and apply for job",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "Close6 the Browser",
  "keyword": "And "
});
formatter.match({
  "location": "Activity2.loginPage()"
});
formatter.result({
  "duration": 9256834100,
  "status": "passed"
});
formatter.match({
  "location": "Activity2.uncheckcheckbox()"
});
formatter.result({
  "duration": 1231505200,
  "status": "passed"
});
formatter.match({
  "location": "Activity2.adduserdetails()"
});
formatter.result({
  "duration": 3138171500,
  "status": "passed"
});
formatter.match({
  "location": "Activity2.closeBrowser()"
});
formatter.result({
  "duration": 1337097200,
  "status": "passed"
});
});