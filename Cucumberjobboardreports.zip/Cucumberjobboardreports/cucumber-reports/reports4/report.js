$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity4.feature");
formatter.feature({
  "line": 2,
  "name": "Data driven test with Example",
  "description": "",
  "id": "data-driven-test-with-example",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_8"
    }
  ]
});
formatter.scenarioOutline({
  "line": 4,
  "name": "Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 5,
  "name": "User8 is on Login page and navigate to post jobs page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user8 logs in with email \"\u003cemail\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "user8 logs in with jobtitle \"\u003cjobtitle\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "user8 logs in with location \"\u003clocation\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "user8 logs in with appliacation url \"\u003capplicationurl\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "user8 logs in with companyname \"\u003ccompanyname\u003e\"",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "user8 logs in with description",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "User8 is on Login page and navigate to post jobs page and verify jobs are created",
  "keyword": "Then "
});
formatter.step({
  "line": 13,
  "name": "Close8 the Browser",
  "keyword": "And "
});
formatter.examples({
  "line": 15,
  "name": "",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario;",
  "rows": [
    {
      "cells": [
        "email",
        "jobtitle",
        "location",
        "applicationurl",
        "companyname"
      ],
      "line": 16,
      "id": "data-driven-test-with-example;testing-with-data-from-scenario;;1"
    },
    {
      "cells": [
        "inchmmmmmmmmm@gmail.com",
        "Automation Tester",
        "delhi",
        "incjhmmmmmmmi@gmail.com",
        "ibm"
      ],
      "line": 17,
      "id": "data-driven-test-with-example;testing-with-data-from-scenario;;2"
    }
  ],
  "keyword": "Examples"
});
formatter.scenario({
  "line": 17,
  "name": "Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario;;2",
  "type": "scenario",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_8"
    }
  ]
});
formatter.step({
  "line": 5,
  "name": "User8 is on Login page and navigate to post jobs page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user8 logs in with email \"inchmmmmmmmmm@gmail.com\"",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "user8 logs in with jobtitle \"Automation Tester\"",
  "matchedColumns": [
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "user8 logs in with location \"delhi\"",
  "matchedColumns": [
    2
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "user8 logs in with appliacation url \"incjhmmmmmmmi@gmail.com\"",
  "matchedColumns": [
    3
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "user8 logs in with companyname \"ibm\"",
  "matchedColumns": [
    4
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "user8 logs in with description",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "User8 is on Login page and navigate to post jobs page and verify jobs are created",
  "keyword": "Then "
});
formatter.step({
  "line": 13,
  "name": "Close8 the Browser",
  "keyword": "And "
});
formatter.match({
  "location": "Activity4.loginPage()"
});
formatter.result({
  "duration": 19131950800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "inchmmmmmmmmm@gmail.com",
      "offset": 26
    }
  ],
  "location": "Activity4.email(String)"
});
formatter.result({
  "duration": 67172000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Automation Tester",
      "offset": 29
    }
  ],
  "location": "Activity4.title(String)"
});
formatter.result({
  "duration": 87814800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "delhi",
      "offset": 29
    }
  ],
  "location": "Activity4.location(String)"
});
formatter.result({
  "duration": 88826100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "incjhmmmmmmmi@gmail.com",
      "offset": 37
    }
  ],
  "location": "Activity4.URL(String)"
});
formatter.result({
  "duration": 111353700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "ibm",
      "offset": 32
    }
  ],
  "location": "Activity4.companyname(String)"
});
formatter.result({
  "duration": 61437500,
  "status": "passed"
});
formatter.match({
  "location": "Activity4.description()"
});
formatter.result({
  "duration": 360468600,
  "status": "passed"
});
formatter.match({
  "location": "Activity4.previewbutton()"
});
formatter.result({
  "duration": 5214185100,
  "status": "passed"
});
formatter.match({
  "location": "Activity4.closeBrowser()"
});
formatter.result({
  "duration": 1553834800,
  "status": "passed"
});
});