$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("Activity3.feature");
formatter.feature({
  "line": 2,
  "name": "Data driven test with Example",
  "description": "",
  "id": "data-driven-test-with-example",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@activity2_7"
    }
  ]
});
formatter.scenario({
  "line": 4,
  "name": "Testing with Data from Scenario",
  "description": "",
  "id": "data-driven-test-with-example;testing-with-data-from-scenario",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "User7 is on Login page and navigate to post jobs page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user logs in with email \"inuhhhhihiahaa@gmail.com\"",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "user logs in with jobtitle \"Automation Tester\"",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "user logs in with location \"Australia\"",
  "keyword": "Then "
});
formatter.step({
  "line": 9,
  "name": "user logs in with appliacation url \"wrr@gmail.com\"",
  "keyword": "Then "
});
formatter.step({
  "line": 10,
  "name": "user logs in with companyname \"HCL\"",
  "keyword": "Then "
});
formatter.step({
  "line": 11,
  "name": "user logs in with description",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "User7 is on Login page and navigate to post jobs page and verify jobs are created",
  "keyword": "Then "
});
formatter.step({
  "line": 13,
  "name": "Close7 the Browser",
  "keyword": "And "
});
formatter.match({
  "location": "Activity3.loginPage()"
});
formatter.result({
  "duration": 18848437900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "inuhhhhihiahaa@gmail.com",
      "offset": 25
    }
  ],
  "location": "Activity3.email(String)"
});
formatter.result({
  "duration": 81155100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Automation Tester",
      "offset": 28
    }
  ],
  "location": "Activity3.title(String)"
});
formatter.result({
  "duration": 146244400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Australia",
      "offset": 28
    }
  ],
  "location": "Activity3.location(String)"
});
formatter.result({
  "duration": 125504700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "wrr@gmail.com",
      "offset": 36
    }
  ],
  "location": "Activity3.URL(String)"
});
formatter.result({
  "duration": 139539000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "HCL",
      "offset": 31
    }
  ],
  "location": "Activity3.companyname(String)"
});
formatter.result({
  "duration": 72127400,
  "status": "passed"
});
formatter.match({
  "location": "Activity3.description()"
});
formatter.result({
  "duration": 342199500,
  "status": "passed"
});
formatter.match({
  "location": "Activity3.previewbutton()"
});
formatter.result({
  "duration": 5298693800,
  "status": "passed"
});
formatter.match({
  "location": "Activity3.closeBrowser()"
});
formatter.result({
  "duration": 1267988300,
  "status": "passed"
});
});